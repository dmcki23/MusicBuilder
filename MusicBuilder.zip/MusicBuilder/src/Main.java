/**
 * Standard Java main class
 */
public class Main {
    /**
     * Standard Java main class
     * @param args command line arguments, not applicable atm
     */
    public static void main(String[] args) {
        //SheetOfMusic som = new SheetOfMusic();
        //Converters converters = new Converters();
        //converters.test();
        MainPanel mp = new MainPanel();
    }
}